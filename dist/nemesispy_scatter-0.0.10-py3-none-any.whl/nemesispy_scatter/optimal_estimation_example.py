from nemesispy_scatter.common.nemesis import NEMESIS
nem = NEMESIS('./example_nemesispy_input.txt')
nem.run_optimal_estimation()
